package softwarehuset;

public class Address {
	private String city, street;
	private int streetNumber;
	
	public Address (String city, String street, int streetNumber){
		this.city = city;
		this.street = street;
		this.streetNumber = streetNumber;
	}
}

