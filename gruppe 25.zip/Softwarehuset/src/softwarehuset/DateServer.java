package softwarehuset;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateServer {
	public Calendar getCurrentDate(){
		return new GregorianCalendar();
	}
}
